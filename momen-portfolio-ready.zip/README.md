# Momen Nashat Portfolio

صفحة Portfolio بسيطة لعرض أمثلة قبل/بعد في إصلاح الأكواد.

## التشغيل
افتح `index.html` مباشرة في المتصفح.

## الرفع
يمكن رفع الملف إلى GitHub ثم ربط المستودع مع Vercel أو Netlify.
